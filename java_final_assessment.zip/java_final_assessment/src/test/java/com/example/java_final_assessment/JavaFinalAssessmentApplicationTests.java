package com.example.java_final_assessment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaFinalAssessmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
